package com.spikart1.AdminDao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spikart1.AdminDto.CustomerDto;
import com.spikart1.AdminRepository.CustomerRepository;

@Repository
public class CustomerDao {

	@Autowired
	CustomerRepository customerRepository;
	
	public void createCustomer(CustomerDto customerDto)
	{
		customerRepository.save(customerDto);
	}

	public Optional<CustomerDto> veriyOtp(int id) {
		Optional<CustomerDto> dto=customerRepository.findById(id);
//		CustomerDto customerDto=dto.get();
//		return customerDto;\
		return dto;
	}
}
