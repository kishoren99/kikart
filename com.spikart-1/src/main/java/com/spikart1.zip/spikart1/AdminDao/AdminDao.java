package com.spikart1.AdminDao;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spikart1.AdminDto.AdminDto;
import com.spikart1.AdminRepository.AdminRepository;

@Repository
public class AdminDao {

	@Autowired
	AdminRepository adminRepository;
	
public String createAccount(AdminDto adminDto)
{
	adminRepository.save(adminDto);
	return "Account Created Successfully";
}


public AdminDto adminValidation(String email)
{
	Optional<AdminDto> dto=adminRepository.findById(email);
	AdminDto adminDto=dto.get();
	return adminDto;
}
	
}
