package com.spikart1.AdminService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spikart1.AdminDao.CustomerDao;
import com.spikart1.AdminDto.CustomerDto;

@Service
public class CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	public void createCustomer(CustomerDto customerDto)
	{
       customerDao.createCustomer(customerDto);
	}

	public String verifyOtp(int id, int otp) {
		Optional<CustomerDto> optional=customerDao.veriyOtp(id);
		if(optional.isPresent())
		{
			CustomerDto d1=optional.get();
			if(d1!=null)
			{
				if(d1.getOtp()==otp)
				{
					return "account created successfully";
				}
				else
				{
					return "please enter proper otp";
				}
			}
		}
		return "account doesn't exist";
	}
}
