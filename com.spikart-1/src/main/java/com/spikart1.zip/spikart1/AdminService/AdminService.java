package com.spikart1.AdminService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spikart1.AdminDao.AdminDao;
import com.spikart1.AdminDto.AdminDto;

@Service
public class AdminService {

	@Autowired
	AdminDao adminDao;
	
	public String createAccount(AdminDto adminDto)
	{
		return adminDao.createAccount(adminDto);
	}
	
	
	public String  adminLoginValidation(String mail,String pswd)
	{
		
		AdminDto adminDto=adminDao.adminValidation(mail);
		if(adminDto!=null)
		{
			if((adminDto.getEmail().equals(mail))&&(adminDto.getPassword().equals(pswd)))
			{
				
			return "account already created";
			}
			else
			{
				return "please enter valid credentials";
			}
		}
		
		return "create account";
	}
	
	
	
  
}
