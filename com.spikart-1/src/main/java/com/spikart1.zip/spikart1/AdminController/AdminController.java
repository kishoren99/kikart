package com.spikart1.AdminController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spikart1.AdminDto.AdminDto;
import com.spikart1.AdminService.AdminService;

@Controller
//@RequestMapping("/spikart")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	//loclhost:8080/signup
	@GetMapping("/signup")
	public String adminSignUp()
	{
		return  "AdminSignup.jsp";
	}
	
	@ResponseBody
	@PostMapping("/register")
	public String createAccount(@ModelAttribute AdminDto adminDto)
	{
		return adminService.createAccount(adminDto);
		
	}
	
	@GetMapping("/Login")
	public String adminLogin()
	{
		return "AdminLogin.jsp";
	}
	
	@ResponseBody
	@PostMapping("/adminlogin")
	public String adminLoginValidation(@ModelAttribute AdminDto adminDto)
	{
		String email=adminDto.getEmail();
		String pswd=adminDto.getPassword();
		if(adminService.adminLoginValidation(email, pswd).equals("create account"))
		{
		
			return adminService.createAccount(adminDto);
		}
	     return adminService.adminLoginValidation(email, pswd);
			
	}
	

	
	
}
